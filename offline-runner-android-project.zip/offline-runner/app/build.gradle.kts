plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jhey14562.offlinerunner"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jhey14562.offlinerunner"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
